package View;

import Service.UserInterface;
import Model.UserDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.Naming;
import java.util.regex.*;

public class SignUpGUI extends JFrame {
    private JTextField usernameField, emailField, nameField, phoneField;
    private JPasswordField passwordField;
    private JButton signUpButton;
    private JButton backButton;

    private UserInterface userService;

    public SignUpGUI() {
        setTitle("Sign Up");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initComponents();
        setLayout();
        setListeners();

        try {
            userService = (UserInterface) Naming.lookup("rmi://127.0.0.1:5000/users");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initComponents() {
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        emailField = new JTextField(20);
        nameField = new JTextField(20);
        phoneField = new JTextField(20);
        signUpButton = new JButton("Sign Up");
        backButton = new JButton("Back");
    }

    private void setLayout() {
        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Phone Number:"));
        panel.add(phoneField);
        panel.add(signUpButton);
        panel.add(backButton);
        add(panel);
    }

    private void setListeners() {
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String email = emailField.getText();
                String name = nameField.getText();
                String phoneNumber = phoneField.getText();

                if (!isValidEmail(email)) {
                    JOptionPane.showMessageDialog(SignUpGUI.this, "Please enter a valid email address.");
                    return;
                }

                if (!isValidPhoneNumber(phoneNumber)) {
                    JOptionPane.showMessageDialog(SignUpGUI.this, "Please enter a valid 10-digit phone number.");
                    return;
                }

                if (!isValidPassword(password)) {
                    JOptionPane.showMessageDialog(SignUpGUI.this, "Password must be at least 6 characters long.");
                    return;
                }

                UserDTO user = new UserDTO(0, username, password, email, name, phoneNumber);

                try {
                    int result = userService.signUp(user);
                    if (result == 1) {
                        JOptionPane.showMessageDialog(SignUpGUI.this, "Sign up successful!");
                        LoginGUI loginGUI = new LoginGUI();
                        loginGUI.setVisible(true);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(SignUpGUI.this, "Failed to sign up.");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(SignUpGUI.this, "An error occurred while signing up.");
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LoginGUI loginGUI = new LoginGUI();
                loginGUI.setVisible(true);
                dispose();
            }
        });
    }

    private boolean isValidEmail(String email) {
        return email.contains("@");
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("\\d{10}");
    }

    private boolean isValidPassword(String password) {
        return password.length() >= 6;
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            SignUpGUI signUpGUI = new SignUpGUI();
            signUpGUI.setVisible(true);
        });
    }
}
