package View;

import Service.EventInterface;
import Model.EventDTO;
import Model.StadiumDTO;
import static com.itextpdf.kernel.pdf.PdfName.Row;
import com.itextpdf.layout.element.Cell;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.Naming;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;

public class EventGUI extends JFrame {

    private JTextField idField, nameField, searchField;
    private JComboBox<StadiumDTO> stadiumComboBox; // New JComboBox for stadiums
    private JButton addButton, updateButton, deleteButton;
    private JTable eventTable;
    private DefaultTableModel tableModel;
    private JDatePickerImpl datePicker; 
    private JButton exportButton;

    private EventInterface eventService;

    public EventGUI() {
        setTitle("Event Management");
        setSize(1200, 600); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initComponents();
        setLayout();
        setListeners();

        try {
            eventService = (EventInterface) Naming.lookup("rmi://127.0.0.1:5000/event");
            loadStadiums(); // Load stadiums into the combo box
        } catch (Exception e) {
            e.printStackTrace();
        }

        refreshTable();
    }

    private void initComponents() {
        idField = new JTextField(10);
        nameField = new JTextField(20);
        searchField = new JTextField(20);

        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        exportButton = new JButton("Export Excel");

        String[] columnNames = {"ID", "Name", "Date", "Stadium"};
        tableModel = new DefaultTableModel(columnNames, 0);
        eventTable = new JTable(tableModel);

        // Initialize the JDatePicker component
        UtilDateModel model = new UtilDateModel();
        Properties properties = new Properties();
        JDatePanelImpl datePanel = new JDatePanelImpl(model, properties);

        // Create a formatter for date formatting
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        JDatePickerImpl datePickerImpl = new JDatePickerImpl(datePanel, new JFormattedTextField.AbstractFormatter() {
            @Override
            public Object stringToValue(String text) throws java.text.ParseException {
                return dateFormat.parse(text);
            }

            @Override
            public String valueToString(Object value) throws java.text.ParseException {
                if (value instanceof Date) {
                    return dateFormat.format((Date) value);
                }
                return "";
            }
        });
        datePicker = datePickerImpl;

        stadiumComboBox = new JComboBox<>(); // Initialize the stadium combo box
    }

    private void setLayout() {
        JPanel inputPanel = new JPanel(new FlowLayout());
        inputPanel.add(new JLabel("ID:"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Date:"));
        inputPanel.add((JComponent) datePicker); // Add the JDatePicker component
        inputPanel.add(new JLabel("Stadium:"));
        inputPanel.add(stadiumComboBox); // Add the stadium combo box
        inputPanel.add(addButton);
        inputPanel.add(updateButton);
        inputPanel.add(deleteButton);
        inputPanel.add(exportButton);

        JPanel searchPanel = new JPanel(new FlowLayout());
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        

        JScrollPane scrollPane = new JScrollPane(eventTable);

        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(searchPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    private void setListeners() {
        // Action listeners for buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String date = ""; // Initialize date string
                Object selectedDateObject = datePicker.getModel().getValue();
                if (selectedDateObject instanceof Date) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    date = dateFormat.format((Date) selectedDateObject);
                }
                StadiumDTO selectedStadium = (StadiumDTO) stadiumComboBox.getSelectedItem();
                String stadium = selectedStadium != null ? selectedStadium.getName() : "";
                EventDTO event = new EventDTO(0, name, date, stadium);
                try {
                    int result = eventService.addEvent(event);
                    if (result == 1) {
                        refreshTable();
                        clearFields();
                        JOptionPane.showMessageDialog(EventGUI.this, "Event Added Successful.");
                    } else {
                        JOptionPane.showMessageDialog(EventGUI.this, "Failed to add event.");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                String date = ""; // Initialize date string
                Object selectedDateObject = datePicker.getModel().getValue();
                if (selectedDateObject instanceof Date) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    date = dateFormat.format((Date) selectedDateObject);
                }
                StadiumDTO selectedStadium = (StadiumDTO) stadiumComboBox.getSelectedItem();
                String stadium = selectedStadium != null ? selectedStadium.getName() : "";
                EventDTO event = new EventDTO(id, name, date, stadium);
                try {
                    int result = eventService.updateEvent(event);
                    if (result == 1) {
                        refreshTable();
                        clearFields();
                    } else {
                        JOptionPane.showMessageDialog(EventGUI.this, "Failed to update event.");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idField.getText());
                EventDTO event = new EventDTO();
                event.setId(id);
                try {
                    int result = eventService.deleteEvent(event);
                    if (result == 1) {
                        refreshTable();
                        clearFields();
                    } else {
                        JOptionPane.showMessageDialog(EventGUI.this, "Failed to delete event.");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        searchField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchText = searchField.getText().toLowerCase();
                if (!searchText.isEmpty()) {
                    try {
                        List<EventDTO> filteredEvents = eventService.retrieveEvents().stream()
                                .filter(event -> event.getName().toLowerCase().contains(searchText))
                                .collect(Collectors.toList());
                        updateTable(filteredEvents);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                } else {
                    refreshTable();
                }
            }
        });
        exportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportToExcel();
            }
        });
    }

    private void refreshTable() {
        try {
            List<EventDTO> events = eventService.retrieveEvents();
            updateTable(events);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateTable(List<EventDTO> events) {
        tableModel.setRowCount(0);
        for (EventDTO event : events) {
            tableModel.addRow(new Object[]{event.getId(), event.getName(), event.getDate(), event.getLocation()});
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        datePicker.getModel().setValue(null);
        stadiumComboBox.setSelectedIndex(-1);
    }

    private void loadStadiums() {
        try {
            List<StadiumDTO> stadiums = eventService.retrieveStadiums();
            for (StadiumDTO stadium : stadiums) {
                stadiumComboBox.addItem(stadium);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
private void exportToExcel() {
        try {
            // Create a new workbook
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Events");

            // Get column headers from table model
            String[] headers = new String[tableModel.getColumnCount()];
            for (int i = 0; i < tableModel.getColumnCount(); i++) {
                headers[i] = tableModel.getColumnName(i);
            }

            // Write column headers
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < headers.length; i++) {
                XSSFCell cell =  (XSSFCell) headerRow.createCell(i);
                cell.setCellValue(headers[i]);
            }
         

// Write data from table model
for (int i = 0; i < tableModel.getRowCount(); i++) {
    Row row = sheet.createRow(i + 1);
    for (int j = 0; j < tableModel.getColumnCount(); j++) {
        Object value = tableModel.getValueAt(i, j);
        XSSFCell cell = (XSSFCell) row.createCell(j);
        if (value != null) {
            // Convert value to String before setting cell value
            cell.setCellValue((String) value);
        }
    }
}



            // Write workbook to file
            String filePath = "events.xlsx";
            try (FileOutputStream outputStream = new FileOutputStream(filePath)) {
                workbook.write(outputStream);
                JOptionPane.showMessageDialog(EventGUI.this, "Excel file exported successfully!");
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(EventGUI.this, "Error exporting Excel file: " + ex.getMessage());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(EventGUI.this, "Error exporting Excel file: " + ex.getMessage());
        }
    }
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            EventGUI gui = new EventGUI();
            gui.setVisible(true);
        });
    }
}
