package View;

import Service.StadiumInteface;
import Model.Stadium;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.rmi.RemoteException;
import java.util.List;

public class ViewStadiums extends JFrame {
    private StadiumInteface stadiumService;

    public ViewStadiums(StadiumInteface stadiumService) {
        this.stadiumService = stadiumService;

        // Set up the JFrame
        setTitle("View Stadiums");
        setSize(800, 600); // Increased size
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Use a BorderLayout
        setLayout(new BorderLayout());

        // Create the JTable
        String[] columnNames = {"Name", "Location", "Capacity"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable stadiumTable = new JTable(tableModel);
        add(new JScrollPane(stadiumTable), BorderLayout.CENTER);

        // Retrieve and display the list of stadiums
        try {
            List<Stadium> stadiums = stadiumService.getAllStadiums();
            for (Stadium stadium : stadiums) {
                String name = stadium.getName();
                String location = stadium.getLocation();
                int capacity = stadium.getCapacity();
                Object[] data = {name, location, capacity};
                tableModel.addRow(data);
            }
        } catch (RemoteException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while retrieving the stadium list", "Error", JOptionPane.ERROR_MESSAGE);
        }

        setVisible(true);
    }
}
