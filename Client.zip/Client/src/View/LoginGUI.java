package View;

import Model.SessionManager;
import Model.UserDTO;
import Service.UserInterface;
import View.SignUpGUI;
import View.TicketGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.Naming;
import java.util.*;
import java.util.concurrent.*;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class LoginGUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField otpField;
    private JButton loginButton, signUpButton, sendOtpButton;

    private UserInterface userService;
    private Map<String, String> otpStore = new ConcurrentHashMap<>();
    private Map<String, Long> otpExpiryStore = new ConcurrentHashMap<>();

    private static final int OTP_EXPIRY_TIME_MINUTES = 5;

    public LoginGUI() {
        setTitle("Login");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        centerFrameOnScreen();

        initComponents();
        setLayout();
        setListeners();

        try {
            userService = (UserInterface) Naming.lookup("rmi://127.0.0.1:5000/users");
        } catch (Exception e) {
            e.printStackTrace();
        }

        startOtpCleanupTask();
    }

    private void initComponents() {
        usernameField = new JTextField(15);
        passwordField = new JPasswordField(15);
        otpField = new JTextField(6); // 6-digit OTP
        loginButton = new JButton("Login");
        signUpButton = new JButton("Sign Up");
        sendOtpButton = new JButton("Send OTP");
    }

    private void setLayout() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Username:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("OTP:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(otpField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(sendOtpButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        panel.add(loginButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        panel.add(signUpButton, gbc);

        add(panel);
    }

    private void setListeners() {
        sendOtpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                try {
                    UserDTO user = userService.login(username, password);
                    if (user != null) {
                        String otp = generateOtp();
                        otpStore.put(username, otp);
                        otpExpiryStore.put(username, System.currentTimeMillis() + OTP_EXPIRY_TIME_MINUTES * 60 * 1000);
                        sendOtpToUser(user, otp);
                        JOptionPane.showMessageDialog(LoginGUI.this, "OTP sent successfully!");
                    } else {
                        JOptionPane.showMessageDialog(LoginGUI.this, "Failed to send OTP.");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(LoginGUI.this, "An error occurred while sending OTP.");
                }
            }
        });

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String otp = otpField.getText();

                try {
                    if (username.equals("admin") && password.equals("admin")) {
                        // Admin login without OTP
                        JOptionPane.showMessageDialog(LoginGUI.this, "Admin login successful!");
                        dispose(); // Close the login window
                        EventQueue.invokeLater(() -> {
                            AllFrameGUI allFrameGUI = new AllFrameGUI();
                            allFrameGUI.setVisible(true);
                        });
                    } else if (verifyOtp(username, otp)) {
                        UserDTO user = userService.login(username, password);
                        if (user != null) {
                            JOptionPane.showMessageDialog(LoginGUI.this, "Login successful!");
                            dispose(); // Close the login window
                            EventQueue.invokeLater(() -> {
                                TicketGUI eventGUI = new TicketGUI();
                                eventGUI.setVisible(true);
                                SessionManager.setCurrentUser(user);
                                System.out.println("User logged in: " + user.getUsername());
                            });
                        } else {
                            JOptionPane.showMessageDialog(LoginGUI.this, "Invalid username or password.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(LoginGUI.this, "Invalid OTP.");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(LoginGUI.this, "An error occurred while trying to login.");
                }
            }
        });

        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SignUpGUI signUpGUI = new SignUpGUI();
                signUpGUI.setVisible(true);
            }
        });
    }

    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

    private void sendOtpToUser(UserDTO user, String otp) {
        String to = user.getEmail();
        String from = "yvannystrong@gmail.com";
        String host = "smtp.gmail.com";

        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host", host);
        properties.setProperty("mail.smtp.port", "587");
        properties.setProperty("mail.smtp.auth", "true");
        properties.setProperty("mail.smtp.starttls.enable", "true");

        Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("yvannystrong@gmail.com", "kslupyxkszxpzfje");
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("Your OTP Code");
            message.setText("Dear " + user.getUsername() + ",\n\nYour OTP code is: " + otp + "\n\nBest regards,\nStade Management System");
            Transport.send(message);
            System.out.println("OTP email sent successfully...");
        } catch (MessagingException mex) {
            mex.printStackTrace();
            System.out.println("Error while sending OTP email: " + mex);
        }
    }

    private boolean verifyOtp(String username, String otp) {
        String storedOtp = otpStore.get(username);
        Long expiryTime = otpExpiryStore.get(username);

        if (storedOtp != null && storedOtp.equals(otp) && expiryTime != null && System.currentTimeMillis() <= expiryTime) {
            otpStore.remove(username);
            otpExpiryStore.remove(username);
            return true;
        }
        return false;
    }

    private void startOtpCleanupTask() {
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> {
            long currentTime = System.currentTimeMillis();
            otpExpiryStore.entrySet().removeIf(entry -> entry.getValue() <= currentTime);
            otpStore.keySet().removeIf(username -> !otpExpiryStore.containsKey(username));
        }, 1, 1, TimeUnit.MINUTES);
    }

    private void centerFrameOnScreen() {
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(dim.width / 2 - getSize().width / 2, dim.height / 2 - getSize().height / 2);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            LoginGUI loginGUI = new LoginGUI();
            loginGUI.setVisible(true);
        });
    }
}
