package View;

import Model.EventDTO;
import Model.UserDTO;
import Service.UserInterface;
import View.UserTableModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.List;
import java.util.stream.Collectors;

public class UserGUI extends JFrame {
    private JTable userTable;
    private JScrollPane scrollPane;
    private JTextField searchField;
    private JButton deleteButton;
    private JButton updateButton;

    private UserInterface userService;
    UserTableModel model ;//= new UserTableModel(users);

    public UserGUI() {
        setTitle("User Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initComponents();
        setLayout();
        setListeners();

        try {
            userService = (UserInterface) Naming.lookup("rmi://127.0.0.1:5000/users");
            loadUserTable();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initComponents() {
        userTable = new JTable();
        scrollPane = new JScrollPane(userTable);
        searchField = new JTextField(20);
        deleteButton = new JButton("Delete");
        updateButton = new JButton("Update");
    }

    private void setLayout() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.add(new JLabel("Search:"));
        bottomPanel.add(searchField);
        bottomPanel.add(deleteButton);
        bottomPanel.add(updateButton);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        add(panel);
    }

    private void setListeners() {
        deleteButton.addActionListener(e -> deleteUser());
        updateButton.addActionListener(e -> updateUser());
        searchField.addActionListener(e -> searchUser());
    }

    private void loadUserTable() {
        try {
            List<UserDTO> users = userService.getAllUsers();
            UserTableModel model = new UserTableModel(users);
            userTable.setModel(model);
        } catch (RemoteException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(UserGUI.this, "Error loading user data: " + e.getMessage());
        }
    }

    private void deleteUser() {
        int id = Integer.parseInt(searchField.getText());
        UserDTO user = new UserDTO();
        user.setId(id);
        try {
            int result = userService.deleteUser(user);
            if (result == 1) {
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(UserGUI.this, "Failed to delete user.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void searchUser() {
        String searchText = searchField.getText().toLowerCase();
        if (!searchText.isEmpty()) {
            try {
                List<UserDTO> filteredUsers = userService.getAllUsers().stream()
                        .filter(user -> user.getName().toLowerCase().contains(searchText))
                        .collect(Collectors.toList());
                updateTable(filteredUsers);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            refreshTable();
        }
    }
private void updateTable(List<UserDTO> users) {
    DefaultTableModel model = (DefaultTableModel) userTable.getModel();
    model.setRowCount(0);
    for (UserDTO user : users) {
        model.addRow(new Object[]{user.getId(), user.getName(), user.getEmail(), user.getPhoneNumber()});
    }
}

    private void updateUser() {
        // Implement update operation
    }

    private void refreshTable() {
        loadUserTable();
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            UserGUI userGUI = new UserGUI();
            userGUI.setVisible(true);
        });
    }
}
