package View;

import Service.StadiumInteface;
import Model.Stadium;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import javax.imageio.ImageIO;
import java.util.List;

public class RegisterStadium extends JFrame {
    private JTextField nameField, locationField, capacityField;
    private JButton registerButton, viewStadiumsButton;

    private StadiumInteface stadiumService;
    private BufferedImage backgroundImage;

    public RegisterStadium() {
        // Load the background image
        try {
            backgroundImage = ImageIO.read(new File("1920px-Wankhede_Panoramic_ICC_WCF - Copy (2).jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set up the JFrame
        setTitle("Register Stadium");
        setSize(800, 600); // Increased size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Use a custom JPanel with a background image
        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(new GridLayout(5, 2, 10, 10));
        setContentPane(backgroundPanel);

        // Add components
        backgroundPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        backgroundPanel.add(nameField);

        backgroundPanel.add(new JLabel("Location:"));
        locationField = new JTextField();
        backgroundPanel.add(locationField);

        backgroundPanel.add(new JLabel("Capacity:"));
        capacityField = new JTextField();
        backgroundPanel.add(capacityField);

        registerButton = new JButton("Register Stadium");
        backgroundPanel.add(registerButton);

        viewStadiumsButton = new JButton("View Stadiums");
        backgroundPanel.add(viewStadiumsButton);

        // Initialize the RMI connection
        try {
            Registry registry = LocateRegistry.getRegistry("127.0.0.1", 5000);
            stadiumService = (StadiumInteface) registry.lookup("stadium");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Add action listener to the register button
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerStadium();
            }
        });

        // Add action listener to the view stadiums button
        viewStadiumsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewStadiums();
            }
        });

        setVisible(true);
    }

    private void registerStadium() {
        String name = nameField.getText();
        String location = locationField.getText();
        int capacity;

        try {
            capacity = Integer.parseInt(capacityField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Capacity must be a number", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Stadium stadium = new Stadium();
        stadium.setName(name);
        stadium.setLocation(location);
        stadium.setCapacity(capacity);

        try {
            int result = stadiumService.addStadium(stadium);
            if (result == 1) {
                JOptionPane.showMessageDialog(this, "Stadium registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to register stadium", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while registering the stadium", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewStadiums() {
        new ViewStadiums(stadiumService);
    }

    private class BackgroundPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RegisterStadium();
            }
        });
    }
}
