/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AllFrameGUI extends JFrame {
    public AllFrameGUI() {
        setTitle("Admin Dashboard");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        centerFrameOnScreen();
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        
        JButton ticketButton = new JButton("Manage Tickets");
        JButton eventButton = new JButton("Manage Events");
        JButton userButton = new JButton("Manage Users");
        JButton stadiumButton = new JButton("Manage Stadiums");

        panel.add(ticketButton);
        panel.add(eventButton);
        panel.add(userButton);
        panel.add(stadiumButton);

        add(panel);

        ticketButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TicketGUI ticketGUI = new TicketGUI();
                ticketGUI.setVisible(true);
            }
        });

        eventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EventGUI eventGUI = new EventGUI();
                eventGUI.setVisible(true);
            }
        });

        userButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UserGUI userGUI = new UserGUI();
                userGUI.setVisible(true);
            }
        });

        stadiumButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RegisterStadium stadiumGUI = new RegisterStadium();
                stadiumGUI.setVisible(true);
            }
        });
    }

    private void centerFrameOnScreen() {
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(dim.width / 2 - getSize().width / 2, dim.height / 2 - getSize().height / 2);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            AllFrameGUI allFrameGUI = new AllFrameGUI();
            allFrameGUI.setVisible(true);
        });
    }
}
