package View;

import Service.TicketInterface;
import Service.EventInterface;
import Model.TicketDTO;
import Model.EventDTO;
import Model.SessionManager;
import Model.UserDTO;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.rmi.Naming;
import java.util.List;

public class TicketGUI extends JFrame {
    private JComboBox<EventDTO> eventComboBox;
    private JComboBox<String> seatComboBox;
    private JButton buyButton;
    private JLabel priceLabel;
    private TicketInterface ticketService;
    private EventInterface eventService;

    public TicketGUI() {
        setTitle("Ticket Management");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        centerFrameOnScreen();

        initComponents();
        setLayout();
        setListeners();

        try {
            ticketService = (TicketInterface) Naming.lookup("rmi://127.0.0.1:5000/ticket");
            eventService = (EventInterface) Naming.lookup("rmi://127.0.0.1:5000/event");
            loadEvents(); 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initComponents() {
        eventComboBox = new JComboBox<>();
        seatComboBox = new JComboBox<>();
        buyButton = new JButton("Buy Ticket");
        priceLabel = new JLabel("Price: ");

        // Disable seat combo box initially
        seatComboBox.setEnabled(false);
    }

    private void setLayout() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        panel.add(new JLabel("Select Event:"));
        panel.add(eventComboBox);
        panel.add(new JLabel("Select Seat:"));
        panel.add(seatComboBox);
        panel.add(new JLabel("Price:"));
        panel.add(priceLabel);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(buyButton);

        add(panel, BorderLayout.CENTER);
    }

private void setListeners() {
    eventComboBox.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // When an event is selected, enable seat selection and update price
            EventDTO selectedEvent = (EventDTO) eventComboBox.getSelectedItem();
            if (selectedEvent != null) {
                loadSeats(selectedEvent.getId());
                updatePrice(selectedEvent); // Initial price update for selected event
            }
        }
    });

    seatComboBox.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // When a seat is selected, update the price
            EventDTO selectedEvent = (EventDTO) eventComboBox.getSelectedItem();
            if (selectedEvent != null) {
                updatePrice(selectedEvent);
            }
        }
    });

   buyButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Handle ticket purchase
            EventDTO selectedEvent = (EventDTO) eventComboBox.getSelectedItem();
            String selectedSeat = (String) seatComboBox.getSelectedItem();
            if (selectedEvent != null && selectedSeat != null) {
                double price = calculatePrice(selectedEvent, selectedSeat);
                // Extract the seat number from the selected seat
                int seatNumber = Integer.parseInt(selectedSeat.split(" ")[1]);
                TicketDTO ticketDTO = new TicketDTO();
                ticketDTO.setEventId(selectedEvent.getId());
                ticketDTO.setSeatNumber(String.valueOf(seatNumber));
                ticketDTO.setPrice(price);

                // Debug statements
                UserDTO currentUser = SessionManager.getCurrentUser();
                System.out.println("Current user in GUI: " + (currentUser != null ? currentUser.getUsername() : "none"));

                // Here you can call the ticketService to create a new ticket
                try {
                    // Assuming createTicket method expects TicketDTO
                    ticketService.createTicket(ticketDTO);
                    JOptionPane.showMessageDialog(TicketGUI.this, "Ticket bought successfully! Price: " + price);
                    generatePdfTicket(ticketDTO, selectedEvent, currentUser); // Generate and show PDF
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(TicketGUI.this, "Failed to buy ticket.");
                }
            }
        }
    });
    }

    private void loadEvents() {
        try {
            List<EventDTO> events = eventService.retrieveEvents();
            for (EventDTO event : events) {
                eventComboBox.addItem(event);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadSeats(int eventId) {
        // Dummy method to load seats, replace with your implementation
        seatComboBox.removeAllItems();
        // Load available seats based on the selected event
        // For demonstration purposes, let's assume there are only 10 seats available for each event
//        for (int i = 1; i <= 10; i++) {
            seatComboBox.addItem("VVIP 1");
            seatComboBox.addItem("VVIP 2");
            seatComboBox.addItem("VVIP 3");
            seatComboBox.addItem("VVIP 4");
            seatComboBox.addItem("VVIP 5");
            seatComboBox.addItem("VIP 1");
            seatComboBox.addItem("VIP 2");
            seatComboBox.addItem("VIP 3");
            seatComboBox.addItem("VIP 4");
            seatComboBox.addItem("VIP 5");
            seatComboBox.addItem("REGURAL 1");
            seatComboBox.addItem("REGURAL 2");
            seatComboBox.addItem("REGURAL 3");
            seatComboBox.addItem("REGURAL 4");
            seatComboBox.addItem("REGURAL 5");
            seatComboBox.addItem("REGURAL 6");
            
//        }
        // Enable seat selection
        seatComboBox.setEnabled(true);
    }

private void updatePrice(EventDTO event) {
    String selectedSeat = (String) seatComboBox.getSelectedItem();
    if (selectedSeat != null) {
        double price = calculatePrice(event, selectedSeat);
        priceLabel.setText("Price: " + price);
    } else {
        priceLabel.setText("Price: ");
    }
}


private double calculatePrice(EventDTO event, String seat) {
    if (seat.startsWith("VIP")) {
        return 20000.0;
    } else if (seat.startsWith("VVIP")) {
        return 300000.0;
    } else {
        return 15000.0;
    }
}


    private void generatePdfTicket(TicketDTO ticketDTO, EventDTO eventDTO, UserDTO userDTO) {
    try {
        String dest = "ticket_" + ticketDTO.getEventId() + "_" + ticketDTO.getSeatNumber() + ".pdf";
        String selectedSeat = (String) seatComboBox.getSelectedItem();
        PdfWriter writer = new PdfWriter(dest);
        PdfDocument pdfDoc = new PdfDocument(writer);
        Document document = new Document(pdfDoc, PageSize.A4);

        // Fonts
        PdfFont titleFont = PdfFontFactory.createFont(com.itextpdf.io.font.constants.StandardFonts.HELVETICA_BOLD);
        PdfFont normalFont = PdfFontFactory.createFont(com.itextpdf.io.font.constants.StandardFonts.HELVETICA);

        // Title
        Paragraph title = new Paragraph("Ticket Details")
                .setFont(titleFont)
                .setFontSize(20)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(20);
        document.add(title);

        // Event details table
        float[] columnWidths = {1, 3};
        Table table = new Table(columnWidths);
        table.addCell(new Paragraph("User Name:").setFont(normalFont).setBold());
        table.addCell(new Paragraph(userDTO.getUsername()).setFont(normalFont));

        table.addCell(new Paragraph("Event:").setFont(normalFont).setBold());
        table.addCell(new Paragraph(eventDTO.getName()).setFont(normalFont));
        
        table.addCell(new Paragraph("Date:").setFont(normalFont).setBold());
        table.addCell(new Paragraph(eventDTO.getDate().toString()).setFont(normalFont));
        
        table.addCell(new Paragraph("Location:").setFont(normalFont).setBold());
        table.addCell(new Paragraph(eventDTO.getLocation()).setFont(normalFont));
        
        table.addCell(new Paragraph("Seat Number:").setFont(normalFont).setBold());
        table.addCell(new Paragraph(ticketDTO.getSeatNumber()+" "+selectedSeat).setFont(normalFont));
        
        table.addCell(new Paragraph("Price:").setFont(normalFont).setBold());
        table.addCell(new Paragraph(String.valueOf(ticketDTO.getPrice())).setFont(normalFont));
        
        

        table.setMarginBottom(20);
        document.add(table);

        // Footer
        Paragraph footer = new Paragraph("Thank you for your purchase!")
                .setFont(normalFont)
                .setFontSize(12)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginTop(20);
        document.add(footer);

        document.close();
        System.out.println("Ticket PDF created successfully at " + dest);
        
        // Show the ticket in a JOptionPane
        JOptionPane.showMessageDialog(TicketGUI.this, new JLabel("Ticket bought successfully! PDF printed at " + dest), "Ticket PDF", JOptionPane.INFORMATION_MESSAGE);
        StringBuilder ticketDetails = new StringBuilder();
        ticketDetails.append("User Name: ").append(userDTO.getUsername()).append("\n");
        ticketDetails.append("Event: ").append(eventDTO.getName()).append("\n");
        ticketDetails.append("Date: ").append(eventDTO.getDate().toString()).append("\n");
        ticketDetails.append("Location: ").append(eventDTO.getLocation()).append("\n");
        ticketDetails.append("Seat Number: ").append(ticketDTO.getSeatNumber()).append(" ").append(selectedSeat).append("\n");
        ticketDetails.append("Price: ").append(ticketDTO.getPrice()).append("\n");

        // Show the ticket details in a JOptionPane
        JOptionPane.showMessageDialog(null, ticketDetails.toString(), "Ticket Details", JOptionPane.INFORMATION_MESSAGE);

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(TicketGUI.this, "Failed to generate PDF.");
    }
}


    private void centerFrameOnScreen() {
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(dim.width / 2 - getSize().width / 2, dim.height / 2 - getSize().height / 2);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            TicketGUI ticketGUI = new TicketGUI();
            ticketGUI.setVisible(true);
        });
    }
}
