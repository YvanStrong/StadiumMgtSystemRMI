package Model;

public class SessionManager {
    private static UserDTO currentUser;

    public static void setCurrentUser(UserDTO user) {
        currentUser = user;
        System.out.println("Current user set: " + (currentUser != null ? currentUser.getUsername() : "none")); // Debug statement
    }

    public static UserDTO getCurrentUser() {
        System.out.println("Getting current user: " + (currentUser != null ? currentUser.getUsername() : "none")); // Debug statement
        return currentUser;
    }

    public static int getLoggedInUserId() {
        if (currentUser != null) {
            return currentUser.getId();
        }
        throw new RuntimeException("User not logged in");
    }
}
