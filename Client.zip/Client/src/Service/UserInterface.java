package Service;

import Model.UserDTO;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import javax.mail.MessagingException;

public interface UserInterface extends Remote {
    int signUp(UserDTO user) throws RemoteException;
    UserDTO login(String username, String password) throws RemoteException;
    boolean sendOtp(String username, String password) throws RemoteException;
    UserDTO loginWithOtp(String username, String password, String otp) throws RemoteException;

    public void sendOtpToUser(UserDTO user, String otp);

    public List<UserDTO> getAllUsers() throws RemoteException;
    int updateUser(UserDTO userD) throws RemoteException;
    int deleteUser(UserDTO userD) throws RemoteException;
    
}
