/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Model.Stadium;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 *
 * @author Yvan Strong
 */
public interface StadiumInteface extends Remote{
    int addStadium(Stadium stadium) throws RemoteException;
    Stadium getStadium(int id) throws RemoteException;
    List<Stadium> getAllStadiums() throws RemoteException;
    int updateStadium(Stadium stadium) throws RemoteException;
    int deleteStadium(Stadium stadium) throws RemoteException;
}
